package VueControleur.Menus;
import javax.swing.JFrame;

import java.awt.*;
import VueControleur.Menus.*;
import Modele.ModeleMenu;
import Maths.Math;
/**
 * Cette classe représente la vue du menu VueControleur.Menus.CP dans le cadre du patron de conception MVP.
 * On y retrouve dedans uniquement l'aspect graphique du menu.
 * Le menu VueControleur.Menus.CP ne donne accès eux matières enseignées au niveau VueControleur.Menus.CP
 *
 * @author nolan
 */
public class CP extends JFrame {
    // Variables declaration - do not modify
    private javax.swing.JButton MenuButton1;
    private javax.swing.JButton MenuButton2;
    private javax.swing.JLabel gameTitle;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanelTitle;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel menuTitle;
    private javax.swing.JPanel tabMenu;
    private Controlleur controlleur;
    
    public CP(ModeleMenu module) {
    	this.controlleur = new Controlleur(module);
    	initComponents();
    }


    /**
     * Classe interne jouant le role de contrôleur
     *
     *
     * 1 - Lancer les menus des différentes matières
     * 2 - Revenir au Menu principal
     */
    public class Controlleur{
        /**
         *  attribut jouant le rôle de modèle dans le cadre du patron de conception MVC
         */
        ModeleMenu menuModele;

        /**
         * Constructeur permettant d'initialiser le controlleur
         * @param menuModele classe jouant le rôle de modèle dans le cadre du patron de conception MVC
         */
        private Controlleur(ModeleMenu menuModele) {
            this.menuModele = menuModele;
        }

        /**
         *
         * @param action entier désignant l'action à faire
         *               1 - Lancer le menu Français
         *               2 - Lancer le menu Maths
         *               3 - Relancer le menu Principal
         */
        public void actionToDo(int action){
            switch (action){
                case 1:
                	CP.this.dispose();
                    //new Français(this.menuModele).setVisible(true);
                    break;
                case 2:
                	CP.this.dispose();
                    new Math("CP");
                    break;
                case 3:
                	CP.this.dispose();
                    new Menuprincipale(this.menuModele).setVisible(true);
                    break;
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    protected void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanelTitle = new javax.swing.JPanel();
        gameTitle = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        menuTitle = new javax.swing.JLabel();
        tabMenu = new javax.swing.JPanel();
        MenuButton1 = new javax.swing.JButton();
        MenuButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 204, 255));

        jPanelTitle.setBackground(new java.awt.Color(102, 204, 255));

        gameTitle.setFont(new java.awt.Font("Cantarell Extra Bold", 1, 48)); // NOI18N
        gameTitle.setForeground(new java.awt.Color(86, 109, 255));
        gameTitle.setText("E-learning");
        gameTitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
            	controlleur.actionToDo(3);
            }
        });


        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setAlignmentY(1.0F);
        jSeparator1.setPreferredSize(new java.awt.Dimension(50, 20));

        menuTitle.setBackground(new java.awt.Color(86, 109, 255));
        menuTitle.setFont(new java.awt.Font("Cantarell", 1, 24)); // NOI18N
        menuTitle.setForeground(new java.awt.Color(255, 255, 255));
        menuTitle.setText("CP");
        menuTitle.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout jPanelTitleLayout = new javax.swing.GroupLayout(jPanelTitle);
        jPanelTitle.setLayout(jPanelTitleLayout);
        jPanelTitleLayout.setHorizontalGroup(
                jPanelTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanelTitleLayout.createSequentialGroup()
                                .addGroup(jPanelTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanelTitleLayout.createSequentialGroup()
                                                .addGap(99, 99, 99)
                                                .addComponent(gameTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanelTitleLayout.createSequentialGroup()
                                                .addGap(75, 75, 75)
                                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanelTitleLayout.createSequentialGroup()
                                                .addGap(157, 157, 157)
                                                .addComponent(menuTitle)))
                                .addContainerGap(93, Short.MAX_VALUE))
        );
        jPanelTitleLayout.setVerticalGroup(
                jPanelTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanelTitleLayout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(gameTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(menuTitle)
                                .addGap(51, 51, 51))
        );

        tabMenu.setBackground(new java.awt.Color(102, 204, 255));

        MenuButton1.setBackground(new java.awt.Color(102, 153, 255));
        MenuButton1.setFont(new java.awt.Font("Cantarell", Font.BOLD, 24)); // NOI18N
        MenuButton1.setForeground(new java.awt.Color(255, 255, 255));
        MenuButton1.setText("Français");
        MenuButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	controlleur.actionToDo(1);
            }
        });

        MenuButton2.setBackground(new java.awt.Color(102, 153, 255));
        MenuButton2.setFont(new java.awt.Font("Cantarell", Font.BOLD, 24)); // NOI18N
        MenuButton2.setForeground(new java.awt.Color(255, 255, 255));
        MenuButton2.setText("Mathématiques");
        MenuButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	controlleur.actionToDo(2);

            }
        });

        javax.swing.GroupLayout tabMenuLayout = new javax.swing.GroupLayout(tabMenu);
        tabMenu.setLayout(tabMenuLayout);
        tabMenuLayout.setHorizontalGroup(
                tabMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tabMenuLayout.createSequentialGroup()
                                .addContainerGap(153, Short.MAX_VALUE)
                                .addGroup(tabMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(MenuButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(MenuButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(143, 143, 143))
        );
        tabMenuLayout.setVerticalGroup(
                tabMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(tabMenuLayout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(MenuButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(MenuButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(287, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap(278, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(tabMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(249, 249, 249))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(jPanelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(367, 367, 367))))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(96, 96, 96)
                                .addComponent(jPanelTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tabMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(56, 56, 56))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }
}
